import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.lang.*;


public class CreateIncrementalFeatureSetsBasedOnMRMR {
	
	public static void main(String[] args) throws IOException{
			
				
			File currentDir = new File(new File(".").getAbsolutePath());
			String curr_dir_path = currentDir.getCanonicalPath();
			
	//		String dataFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/DSP_Features_window_size_9/Sklearn-Dataset-CysPairs/sklearn_windowSize_9_61_features_1224final.txt";
//			String dataFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/IFSWrongSamplesIncluded/train_window_9_61_features.txt";
//			String mrmrFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/IFSWrongSamplesIncluded/feature_rankingWrongSamplesIncluded.txt";
//			String opFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/IFSWrongSamplesIncluded/";
			
			
//			String dataFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/IFSWrongSamplesRemoved/train_window_9_61_features_wrongsamples_removed.txt";
//			String mrmrFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/IFSWrongSamplesRemoved/feature_rankingWrongSamplesRemoved.txt";
//			String opFilePath = curr_dir_path+"/DisulfidePredictionAvdeshAndEda/IFSWrongSamplesRemoved/";
			
			
			// String dataFilePath = curr_dir_path+"/feature_file_incremental_feature_1_mrmr.csv";
			String dataFilePath = "/home/mkabir3/Research/DisPredict/8_Feature_selection/MRMR/Old_files/feature_file_incremental_feature_1_mrmr.csv";
			String mrmrFilePath = curr_dir_path+"/feature_ranking_1.txt";
			String opFilePath = curr_dir_path+"/";
			int total_number_of_features = 93;
			
			
						
			createIFSSet(dataFilePath, mrmrFilePath, opFilePath, total_number_of_features);
			
				
	}
	
	
	public static void createIFSSet(String dataFilePath, String mrmrFilePath, String opFilePath, int total_number_of_features) throws IOException{
		
		BufferedReader dataRd = BufferReaderAndWriter.getReader(new File(dataFilePath));
		String dataLine;
		BufferedReader mrmrRd = BufferReaderAndWriter.getReader(new File(mrmrFilePath));
		String mrmrLine;
		
		List<String[]> features = new ArrayList<String[]>();
		List<Integer> rankedFeatures = new ArrayList<Integer>();
		
		while((dataLine = dataRd.readLine())!=null){ // read data file and load into features list of arrays
								
			String[] dataElem = dataLine.split(",");
			features.add(dataElem);
			
			
		}
		
		dataRd.close();
		
		while((mrmrLine = mrmrRd.readLine())!=null){ // read mrmr file and load ranked features into rankedFeatures list of integers
			
			System.out.println(mrmrLine);

			if(!mrmrLine.equalsIgnoreCase("*** mRMR features *** ")){
				
				continue;
			}
			
			while((mrmrLine = mrmrRd.readLine())!=null){
				
				if(mrmrLine.length() == 0){
					
					break;
					
				}
												
				String[] mrmrElem = mrmrLine.split("\t");
				
				if(mrmrElem[0].trim().equalsIgnoreCase("Order")){
					
					continue;
				}
				
				rankedFeatures.add(Integer.parseInt(mrmrElem[1].trim()));
				
			}
			
			if(mrmrLine.length() == 0){
				
				break;
				
			}
			
		}
		
		mrmrRd.close();
		
		// sometimes the mrmr ranking method does not rank all the features ....
		// so in such case the features which does not get ranked are inserted explicitly at the end of the ranked features list
		for(int i = 1; i <= total_number_of_features; i++){
			
			if(!rankedFeatures.contains(i)){
				
				rankedFeatures.add(i);
				
			}
			
		}
		
		double num_features = (double)(features.get(0).length-2)/10;
		int setSize = (int)Math.ceil(num_features)+1;
		
		System.out.println(setSize);
		
		int num_feat_to_inc = 1; 
		
		for(int i = 0; i < setSize; i++){
			
			String dirName = opFilePath+"Set"+(i+1);
			new File(dirName).mkdir();
			String fileName = opFilePath+"Set"+(i+1)+"/train-set"+(i+1)+".txt";
			BufferedWriter	bw = BufferReaderAndWriter.getWriter(new File(fileName));
			
			for(int j = 0; j < features.size(); j++){
				
				String[] featElem = features.get(j);
				bw.write(featElem[0]+",");
				
				for(int k = 0; k < num_feat_to_inc; k++){
					
					if(k == num_feat_to_inc-1){
						
						bw.write(featElem[rankedFeatures.get(k)]+"\n");
						bw.flush();
						
					}else{
						
						bw.write(featElem[rankedFeatures.get(k)]+",");
												
					}
					
					
				}			
				
				
			}
			
			num_feat_to_inc += 10;
			
			if(num_feat_to_inc > rankedFeatures.size()){
				
				num_feat_to_inc = rankedFeatures.size();
				
			}
			
			bw.close();			
			
		}	
		
		
		
	}
	

}
