./mrmr -i cysSingle_window_9_525_features_wr_sam_nodisulf_fil_cutoff25_zeros.txt -t 0.5 -n 525 -m MID -s 15549 -v 525 > feature_ranking_cysSingle_nodisulf_filtered_cutoff25.txt

223305


./mrmr -i feature_file_incremental_feature_1_mrmr.csv -t 0.5 -n 93 -m MID -s 223305 -v 93 > feature_ranking.txt

/home/mkabir3/Research/DisPredict/6_Windowing/feature_file_incr_feature_1.csv


/home/mkabir3/Research/DisPredict/6_1_header_and_arff/Arff/feature_arff_1.arff

Take input with header****

./mrmr -i /home/mkabir3/Research/DisPredict/6_1_header_and_arff/With_header/feature_file_incr_feature_1_header.csv -t 0.5 -n 84 -m MID -s 131869 -v 84 > feature_ranking_1.txt

./mrmr -i /home/ymamidi/MRMR-1/GeneticAlgo-0.5-MRMR/Stacking-0.5-Copy-num.arff -t 0.5 -n 2074 -m MID -s 495 -v 2074 > feature_ranking_1.txt





./mrmr -i Stacking-0.5.csv -t 0.5 -n 2074 -m MID -s 495 -v 2074 > feature_ranking.txt

./mrmr -i Voom-MRMR-transposed-Copy.csv -t 0.5 -n 16381 -m MID -s 495 -v 16381 > feature_ranking.txt